-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: bddietasyrutinas
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `TransaccionGeneral`
--

DROP TABLE IF EXISTS `TransaccionGeneral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TransaccionGeneral` (
  `idtrangeneral` int NOT NULL AUTO_INCREMENT,
  `fecha` datetime(6) DEFAULT NULL,
  `tipo` varchar(255) DEFAULT NULL,
  `id_asistencia` bigint DEFAULT NULL,
  `iddieta` bigint DEFAULT NULL,
  `id_historial` bigint DEFAULT NULL,
  `id_horario` bigint DEFAULT NULL,
  `id_reunion` bigint DEFAULT NULL,
  `id_rutina` bigint DEFAULT NULL,
  `id_usuario` bigint DEFAULT NULL,
  PRIMARY KEY (`idtrangeneral`),
  KEY `FK5q69yykswsnuuga0tyh7y8s5t` (`id_asistencia`),
  KEY `FK553gywux4alck3go9x4xw5mac` (`iddieta`),
  KEY `FKtfm96ihpthkv8dr7er0bl4ovg` (`id_historial`),
  KEY `FK6kaiotxwyrrtaon8u2p74f36r` (`id_horario`),
  KEY `FKjvb9gqaqx37973ygsk90u81ew` (`id_reunion`),
  KEY `FK57f57olcjywn38g63uhdp03py` (`id_rutina`),
  CONSTRAINT `FK553gywux4alck3go9x4xw5mac` FOREIGN KEY (`iddieta`) REFERENCES `Dieta` (`iddieta`),
  CONSTRAINT `FK57f57olcjywn38g63uhdp03py` FOREIGN KEY (`id_rutina`) REFERENCES `Rutina` (`id_rutina`),
  CONSTRAINT `FK5q69yykswsnuuga0tyh7y8s5t` FOREIGN KEY (`id_asistencia`) REFERENCES `Asistencia` (`id_asistencia`),
  CONSTRAINT `FK6kaiotxwyrrtaon8u2p74f36r` FOREIGN KEY (`id_horario`) REFERENCES `Horario` (`id_horario`),
  CONSTRAINT `FKjvb9gqaqx37973ygsk90u81ew` FOREIGN KEY (`id_reunion`) REFERENCES `Reunion` (`id_reunion`),
  CONSTRAINT `FKtfm96ihpthkv8dr7er0bl4ovg` FOREIGN KEY (`id_historial`) REFERENCES `HistorialMedico` (`id_historial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TransaccionGeneral`
--

LOCK TABLES `TransaccionGeneral` WRITE;
/*!40000 ALTER TABLE `TransaccionGeneral` DISABLE KEYS */;
/*!40000 ALTER TABLE `TransaccionGeneral` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-23 12:29:12
