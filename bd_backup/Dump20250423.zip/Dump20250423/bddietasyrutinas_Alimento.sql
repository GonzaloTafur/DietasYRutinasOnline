-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: bddietasyrutinas
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Alimento`
--

DROP TABLE IF EXISTS `Alimento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Alimento` (
  `id_alimento` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` text,
  `estado` bit(1) DEFAULT NULL,
  `nombre` varchar(40) DEFAULT NULL,
  `nutrientes` varchar(255) DEFAULT NULL,
  `tipo` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_alimento`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Alimento`
--

LOCK TABLES `Alimento` WRITE;
/*!40000 ALTER TABLE `Alimento` DISABLE KEYS */;
INSERT INTO `Alimento` VALUES (1,'Batido con leche (250 ml), plátano (1 unidad), avena (50g). Aporta energía y favorece el crecimiento muscular.',_binary '','Batido de Plátano y Avena','15g de proteína, 70g de carbohidratos, 10g de grasas','Desayuno'),(2,'Pan integral con palta (50g) y huevo frito o cocido (2 unidades). Rico en grasas saludables y proteínas.',_binary '','Pan con Palta y Huevo','20g de proteína, 50g de carbohidratos, 18g de grasas','Desayuno'),(3,'Plato principal. Contiene arroz (200g), pollo (150g), arvejas, zanahorias y aceite vegetal.',_binary '','Arroz con Pollo','30g de proteína, 80g de carbohidratos, 15g de grasas','Almuerzo'),(4,'Lentejas (200g) acompañadas con carne de res (150g) y arroz blanco. Rica en fibra, carbohidratos y proteínas para volumen.',_binary '','Lentejas con Carne','30g de proteína, 80g de carbohidratos, 15g de grasas','Almuerzo'),(5,'Papas rellenas con carne molida de res (100g), con cebolla, ajo, y especias. Aporta calorías para recuperación nocturna.',_binary '','Papa Rellena con Carne','22g de proteína, 50g de carbohidratos, 12g de grasas','Cena'),(6,'Pasta (200g) con pesto de albahaca, espinacas y pollo a la plancha (150g). Alto en carbohidratos y proteínas.',_binary '','Tallarines Verdes con Pollo','28g de proteína, 90g de carbohidratos, 18g de grasas','Cena');
/*!40000 ALTER TABLE `Alimento` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-23 12:29:14
