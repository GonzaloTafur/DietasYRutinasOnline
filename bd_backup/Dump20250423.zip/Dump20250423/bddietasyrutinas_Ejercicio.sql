-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: bddietasyrutinas
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Ejercicio`
--

DROP TABLE IF EXISTS `Ejercicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Ejercicio` (
  `id_ejercicio` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` text,
  `estado` tinyint(1) DEFAULT '1',
  `grupo_muscular` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `repeticiones` varchar(255) DEFAULT NULL,
  `series` int DEFAULT NULL,
  `tipo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_ejercicio`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ejercicio`
--

LOCK TABLES `Ejercicio` WRITE;
/*!40000 ALTER TABLE `Ejercicio` DISABLE KEYS */;
INSERT INTO `Ejercicio` VALUES (1,'Acuéstate en un banco plano con los pies en el suelo. Baja la barra hasta el pecho y empújala hacia arriba hasta estirar los brazos. Mantén control en todo el movimiento.',1,'Pecho','Press de banca','6 a 8',3,'Tren Superior'),(2,'En un banco inclinado, baja la barra o mancuernas hacia el pecho superior. Empuja hacia arriba contrayendo el pecho. Controla el movimiento para evitar lesiones.',1,'Pecho','Press inclinado','6 a 8',3,'Tren Superior'),(3,'Inclina el torso hacia adelante con la barra en las manos. Sube la barra hacia el abdomen y baja controladamente. Mantén la espalda recta durante el ejercicio.',1,'Espalda','Remo con barra','6 a 8',3,'Tren Superior'),(4,'Sostén la barra con las palmas hacia arriba. Flexiona los codos elevando la barra hasta que los antebrazos toquen los bíceps. Baja lentamente sin bloquear los codos.',1,'Biceps','Curl con barra','6 a 8',3,'Tren Superior'),(5,'Acuéstate en un banco, sujeta una barra Z. Flexiona los codos bajando la barra hacia la frente y luego extiende los brazos completamente hacia arriba.',1,'Triceps','Press frances','6 a 8',3,'Tren Superior'),(6,'Sujeta la cuerda o barra en una polea alta. Empuja hacia abajo hasta estirar completamente los codos y vuelve a la posición inicial de forma controlada.',1,'Tríceps','Extensión de tríceps en polea','6 a 8',3,'Tren Superior'),(7,'De pie, con una mancuerna en cada mano, eleva los brazos hacia los lados hasta que estén paralelos al suelo. Baja lentamente controlando el movimiento.',1,'Hombros','Elevaciones laterales','6 a 8',3,'Tren Superior'),(8,'Con la barra sobre los hombros, baja flexionando las rodillas hasta que los muslos estén paralelos al suelo. Sube extendiendo las rodillas y caderas.',1,'Cuádriceps','Sentadilla con barra','6 a 8',3,'Tren Inferior');
/*!40000 ALTER TABLE `Ejercicio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-23 12:29:14
