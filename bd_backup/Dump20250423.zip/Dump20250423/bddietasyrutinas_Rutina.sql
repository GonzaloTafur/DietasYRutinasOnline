-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: bddietasyrutinas
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Rutina`
--

DROP TABLE IF EXISTS `Rutina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Rutina` (
  `id_rutina` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` text,
  `estado` bit(1) DEFAULT NULL,
  `nivel` varchar(25) DEFAULT NULL,
  `nombre` varchar(50) NOT NULL,
  `parteCuerpo` varchar(20) DEFAULT NULL,
  `nutriologo` bigint DEFAULT NULL,
  `objetivo` bigint DEFAULT NULL,
  PRIMARY KEY (`id_rutina`),
  KEY `FK5p5a2sjrd3xni07qjh5g8b0xj` (`nutriologo`),
  KEY `FKonpk2oswih6n3uxs02ngmgayu` (`objetivo`),
  CONSTRAINT `FK5p5a2sjrd3xni07qjh5g8b0xj` FOREIGN KEY (`nutriologo`) REFERENCES `Nutriologo` (`id_usuario`),
  CONSTRAINT `FKonpk2oswih6n3uxs02ngmgayu` FOREIGN KEY (`objetivo`) REFERENCES `Objetivo` (`id_objetivo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rutina`
--

LOCK TABLES `Rutina` WRITE;
/*!40000 ALTER TABLE `Rutina` DISABLE KEYS */;
INSERT INTO `Rutina` VALUES (1,'Esta rutina está diseñada para principiantes en fase de volumen. Comienza con la prensa de banca para activar los músculos del pecho. Se recomienda un descanso de 3 a 4 minutos entre series. Utilice pesos ligeros para asegurar una técnica adecuada. La rutina trabaja los principales músculos del tren superior, favoreciendo el desarrollo de la fuerza y ​​la masa muscular. Concéntrate en mantener una buena forma en cada ejercicio.',_binary '','Principiante','Fuerza Superior I','Tren Superior',NULL,1);
/*!40000 ALTER TABLE `Rutina` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-23 12:29:14
