-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: bddietasyrutinas_copia
-- ------------------------------------------------------
-- Server version	8.0.43-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Dieta`
--

DROP TABLE IF EXISTS `Dieta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Dieta` (
  `id_dieta` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` text,
  `objetivo` enum('V','D') DEFAULT NULL,
  `id_nutriologo` int DEFAULT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_dieta`),
  KEY `FK20stwmvdh5g7hdvvwvcv7kc1a` (`id_nutriologo`),
  KEY `id_objetivo` (`objetivo`) USING BTREE,
  CONSTRAINT `Dieta_ibfk_2` FOREIGN KEY (`id_nutriologo`) REFERENCES `Usuario` (`id_usuario`),
  CONSTRAINT `FK20stwmvdh5g7hdvvwvcv7kc1a` FOREIGN KEY (`id_nutriologo`) REFERENCES `Nutriologo` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='V: VOLUMEN\r\nD: DEFICIT';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Dieta`
--

LOCK TABLES `Dieta` WRITE;
/*!40000 ALTER TABLE `Dieta` DISABLE KEYS */;
INSERT INTO `Dieta` VALUES (1,'Energía completa','Esta dieta está diseñada para quienes buscan aumentar su masa muscular de manera efectiva. Comienza el día con un batido de plátano y avena y pan con palta y huevo , que aportan energía y nutrientes esenciales. El batido de proteínas con frutas refuerza la recuperación post-entrenamiento. El almuerzo incluye arroz con pollo , una rica fuente de carbohidratos y proteínas. El yogurt con quinua es una excelente merienda, y para la cena, el pollo a la plancha con camote ofrece proteínas magras. Recuerda que la cena es solo una recomendación; Si te sobra almuerzo, puedes consumirlo para evitar desperdicios. ¡La calidad de los alimentos es clave para tu progreso!','V',1,1),(4,'Nutrición Vital','Esta dieta está pensada para quienes buscan ganar masa muscular de forma saludable. Comienza el día con un batido de plátano y avena y una tortilla de huevo con queso fresco y espinacas , brindando energía y proteínas. Una media mañana, disfruta de yogur con semillas de chía y frutas , que aporta fibra y grasas saludables. El almuerzo incluye lentejas con carne , ricas en proteínas y hierro, y como merienda, huevos cocidos con palta y pan integral , que ofrece una combinación de proteínas y grasas saludables. La ensalada de menestras con atún cierra el día, aportando proteínas magras. Recuerda que la cena es solo una sugerencia; Si sobra comida del almuerzo, también puedes consumirla para evitar el desperdicio. Mantén un enfoque en la calidad de los alimentos para optimizar tu progreso.','V',4,1),(5,'Fuerza Criolla','Esta dieta está diseñada para quienes desean aumentar masa muscular de manera efectiva. Comienza el día con un licuado de quinua y plátano acompañado de pan con palta y huevo , que proporciona energía y nutrientes esenciales. Una media mañana, disfruta de un batido de mango, avena y proteína , que ofrece carbohidratos y proteínas para mantenerte activo. El almuerzo incluye un delicioso lomo saltado con arroz y papas , que es una fuente completa de proteínas y carbohidratos. En la merienda, opta por yogur con quinua , aportando calcio y fibra. Finaliza el día con una tortilla de espinacas, queso y yuca , ideal para reponer energías. Recuerda que la cena puede variar; Si sobra comida del almuerzo, puedes consumirla, optimizando así tu ingesta y evitando el desperdicio. ¡La calidad de los alimentos es clave en tu camino hacia el volumen!','V',6,1);
/*!40000 ALTER TABLE `Dieta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-24 15:59:34
