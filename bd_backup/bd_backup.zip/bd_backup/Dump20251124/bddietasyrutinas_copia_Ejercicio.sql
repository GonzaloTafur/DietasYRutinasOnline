-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: bddietasyrutinas_copia
-- ------------------------------------------------------
-- Server version	8.0.43-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Ejercicio`
--

DROP TABLE IF EXISTS `Ejercicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Ejercicio` (
  `id_ejercicio` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `grupo_muscular` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `tipo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `series` int NOT NULL,
  `repeticiones` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `descripcion` text,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_ejercicio`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ejercicio`
--

LOCK TABLES `Ejercicio` WRITE;
/*!40000 ALTER TABLE `Ejercicio` DISABLE KEYS */;
INSERT INTO `Ejercicio` VALUES (1,'Press de banca','Pecho','Tren Superior',3,'6 a 8','Acuéstate en un banco plano con los pies en el suelo. Baja la barra hasta el pecho y empújala hacia arriba hasta estirar los brazos. Mantén control en todo el movimiento.',1),(2,'Press inclinado','Pecho','Tren Superior',3,'6 a 8','En un banco inclinado, baja la barra o mancuernas hacia el pecho superior. Empuja hacia arriba contrayendo el pecho. Controla el movimiento para evitar lesiones.',1),(3,'Remo con barra','Espalda','Tren Superior',3,'6 a 8','Inclina el torso hacia adelante con la barra en las manos. Sube la barra hacia el abdomen y baja controladamente. Mantén la espalda recta durante el ejercicio.',1),(4,'Curl con barra','Biceps','Tren Superior',3,'6 a 8','Sostén la barra con las palmas hacia arriba. Flexiona los codos elevando la barra hasta que los antebrazos toquen los bíceps. Baja lentamente sin bloquear los codos.',1),(5,'Press frances','Triceps','Tren Superior',3,'6 a 8','Acuéstate en un banco, sujeta una barra Z. Flexiona los codos bajando la barra hacia la frente y luego extiende los brazos completamente hacia arriba.',1),(6,'Extensión de tríceps en polea','Tríceps','Tren Superior',3,'6 a 8','Sujeta la cuerda o barra en una polea alta. Empuja hacia abajo hasta estirar completamente los codos y vuelve a la posición inicial de forma controlada.',1),(7,'Elevaciones laterales','Hombros','Tren Superior',3,'6 a 8','De pie, con una mancuerna en cada mano, eleva los brazos hacia los lados hasta que estén paralelos al suelo. Baja lentamente controlando el movimiento.',1),(8,'Sentadilla con barra','Cuádriceps','Tren Inferior',3,'6 a 8','Con la barra sobre los hombros, baja flexionando las rodillas hasta que los muslos estén paralelos al suelo. Sube extendiendo las rodillas y caderas.',1);
/*!40000 ALTER TABLE `Ejercicio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-24 15:59:36
