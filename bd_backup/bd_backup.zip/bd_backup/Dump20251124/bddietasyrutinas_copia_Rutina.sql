-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: bddietasyrutinas_copia
-- ------------------------------------------------------
-- Server version	8.0.43-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Rutina`
--

DROP TABLE IF EXISTS `Rutina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Rutina` (
  `id_rutina` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `tipo` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `descripcion` text,
  `objetivo` enum('V','D') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `id_nutriologo` int DEFAULT NULL,
  `nivel` enum('PRINCIPIANTE','INTERMEDIO','AVANZADO') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `parte_cuerpo` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_rutina`),
  KEY `FKr0u16fjcbcamwrbx2jrf9h3hv` (`id_nutriologo`),
  KEY `id_objetivo` (`objetivo`) USING BTREE,
  CONSTRAINT `FKr0u16fjcbcamwrbx2jrf9h3hv` FOREIGN KEY (`id_nutriologo`) REFERENCES `Nutriologo` (`id_usuario`),
  CONSTRAINT `Rutina_ibfk_2` FOREIGN KEY (`id_nutriologo`) REFERENCES `Usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='V: VOLUMEN\r\nD: DEFICIT';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rutina`
--

LOCK TABLES `Rutina` WRITE;
/*!40000 ALTER TABLE `Rutina` DISABLE KEYS */;
INSERT INTO `Rutina` VALUES (1,'Fuerza Superior 1','Volumen','Esta rutina está diseñada para principiantes en fase de volumen. Comienza con la prensa de banca para activar los músculos del pecho. Se recomienda un descanso de 3 a 4 minutos entre series. Utilice pesos ligeros para asegurar una técnica adecuada. La rutina trabaja los principales músculos del tren superior, favoreciendo el desarrollo de la fuerza y ​​la masa muscular. Concéntrate en mantener una buena forma en cada ejercicio.','V',4,'PRINCIPIANTE','Tren Superior',1),(2,'Fuerza Superior 2','Volumen','Esta rutina se enfoca en construir masa muscular en el tren superior. Empieza con la prensa inclinada para activar los pectorales. Realiza de 8 a 12 repeticiones por serie, descansando de 3 a 4 minutos entre ellas. Es crucial mantener un peso ligero y prestar atención a la técnica para evitar lesiones. Las elevaciones laterales ayudan a desarrollar los hombros, mientras que los fondos activan los tríceps. Asegúrese de calentar adecuadamente antes de comenzar.','V',1,'PRINCIPIANTE','Tren Superior',1),(3,'Fuerza Superior 2',NULL,'En esta rutina, se utilizan máquinas y ejercicios con poco peso, ideales para principiantes. Comienza con la prensa de pecho en máquina para facilitar el movimiento. Descansa de 3 a 4 minutos entre series. Focaliza tu atención en la técnica, especialmente en el curl de bíceps. Esta combinación de ejercicios ayudará a aumentar la fuerza y ​​preparar los músculos para cargas más pesadas en el futuro.','V',6,'PRINCIPIANTE','Tren Superior',1);
/*!40000 ALTER TABLE `Rutina` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-24 15:59:34
