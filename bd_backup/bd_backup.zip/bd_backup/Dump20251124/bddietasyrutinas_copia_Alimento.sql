-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: bddietasyrutinas_copia
-- ------------------------------------------------------
-- Server version	8.0.43-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Alimento`
--

DROP TABLE IF EXISTS `Alimento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Alimento` (
  `id_alimento` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `nutrientes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `tipo` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `descripcion` text,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_alimento`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Alimento`
--

LOCK TABLES `Alimento` WRITE;
/*!40000 ALTER TABLE `Alimento` DISABLE KEYS */;
INSERT INTO `Alimento` VALUES (1,'Batido de Plátano y Avena','15g de proteína, 70g de carbohidratos, 10g de grasas','Desayuno','Batido con leche (250 ml), plátano (1 unidad), avena (50g). Aporta energía y favorece el crecimiento muscular.',1),(2,'Pan con Palta y Huevo','20g de proteína, 50g de carbohidratos, 18g de grasas','Desayuno','Pan integral con palta (50g) y huevo frito o cocido (2 unidades). Rico en grasas saludables y proteínas.',1),(3,'Arroz con Pollo','30g de proteína, 80g de carbohidratos, 15g de grasas','Almuerzo','Plato principal. Contiene arroz (200g), pollo (150g), arvejas, zanahorias y aceite vegetal.',1),(4,'Lentejas con Carne','30g de proteína, 80g de carbohidratos, 15g de grasas','Almuerzo','Lentejas (200g) acompañadas con carne de res (150g) y arroz blanco. Rica en fibra, carbohidratos y proteínas para volumen.',1),(5,'Papa Rellena con Carne','22g de proteína, 50g de carbohidratos, 12g de grasas','Cena','Papas rellenas con carne molida de res (100g), con cebolla, ajo, y especias. Aporta calorías para recuperación nocturna.',1),(6,'Tallarines Verdes con Pollo','28g de proteína, 90g de carbohidratos, 18g de grasas','Cena','Pasta (200g) con pesto de albahaca, espinacas y pollo a la plancha (150g). Alto en carbohidratos y proteínas.',1),(7,'Yogurt con Quinua','12g de proteína, 40g de carbohidratos, 5g de grasas','Merienda','Yogurt natural (200 ml) con quinua cocida (50g). Ideal para complementar la ingesta calórica del día.',1);
/*!40000 ALTER TABLE `Alimento` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-24 15:59:33
