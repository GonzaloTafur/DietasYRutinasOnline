USE master
GO

DROP DATABASE IF exists bddietasyrutinas

CREATE DATABASE bddietasyrutinas
GO

USE bddietasyrutinas
GO

CREATE TABLE TipoUsuario(
	idtipousu INTEGER IDENTITY (1, 1) PRIMARY KEY,
	nomtipousu VARCHAR(20),
	esttipousu VARCHAR(20),
)

CREATE TABLE Usuario(
	idusuario INTEGER IDENTITY (1, 1) PRIMARY KEY,
	idtipousu INT,
	nomusuario VARCHAR(20),
	apeusuario VARCHAR(50),
	fechanacimiento DATE,
	nacionalidad VARCHAR(20),
	sexo VARCHAR(10),
	biografia VARCHAR(200),
	estusuario VARCHAR(20),
	correo VARCHAR(50),
	password VARCHAR(255),
	FOREIGN KEY (idtipousu) REFERENCES TipoUsuario(idtipousu) 
)

CREATE TABLE Ejercicio (
    idejercicio INTEGER IDENTITY (1, 1) PRIMARY KEY,
	nomejercicio VARCHAR(60),
	grupomuscular VARCHAR(30),
    tipoejercicio VARCHAR(30),
	series INT,
	repeticiones VARCHAR(10),
    descejercicio VARCHAR(300),
)

CREATE TABLE Rutina (
    idrutina INTEGER IDENTITY (1, 1) PRIMARY KEY,
	nomrutina VARCHAR(30),
    tiporutina VARCHAR(30),
	parteCuerpo VARCHAR(30),
    nivel VARCHAR(30),
    descrutina VARCHAR(700),
    estrutina VARCHAR(20),
    idusuario INTEGER,
    FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario)
)

CREATE TABLE RutinaEjercicio ( 
    id_rutina INTEGER NOT NULL,
    id_ejercicio INTEGER NOT NULL,
    PRIMARY KEY (id_rutina, id_ejercicio),
    FOREIGN KEY (id_rutina) REFERENCES Rutina(idrutina),
    FOREIGN KEY (id_ejercicio) REFERENCES Ejercicio(idejercicio)
)

CREATE TABLE Reunion (
    idreunion INTEGER IDENTITY (1, 1) PRIMARY KEY,
    idusuario INT,
	motivo VARCHAR(60),
    /*fecha DATE,*/
	diaSemana VARCHAR(20),
    horaInicio TIME,
	enlace VARCHAR(300),
	estreunion VARCHAR(20),
	FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario),
)

CREATE TABLE Asistencia ( 
	idasistencia INTEGER IDENTITY (1, 1) PRIMARY KEY,
    idreunion INT,
	idusuario INT,
    fecasistencia DATETIME,
	estados VARCHAR(20),
	estasistencia VARCHAR(20),
    FOREIGN KEY (idreunion) REFERENCES Reunion(idreunion),
	FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario),
)

CREATE TABLE Horario (
    idhorario INTEGER IDENTITY (1, 1) PRIMARY KEY,
    idusuario INT,
	idrutina INT,
    diaSemana VARCHAR(10),
    periodo VARCHAR(10),
	esthorario VARCHAR(20),
	tiempoDescanso INT,
	FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario),
	FOREIGN KEY (idrutina) REFERENCES Rutina(idrutina),
)

CREATE TABLE Alimento (
    idalimento INTEGER IDENTITY (1, 1) PRIMARY KEY,
    nomalimento VARCHAR(80),
    nutrientes VARCHAR(100),
    tipoalimento VARCHAR(30),
	descalimento VARCHAR(300)
)

CREATE TABLE Condicion (
    idcondicion INTEGER IDENTITY (1, 1) PRIMARY KEY,
    nomcondicion VARCHAR(30),
    estcondicion VARCHAR(20)
)

CREATE TABLE Dieta (
    iddieta INTEGER IDENTITY (1, 1) PRIMARY KEY,
    nomdieta VARCHAR(60),
	objdieta VARCHAR(60),
    descdieta VARCHAR(900),
	estdieta VARCHAR(20),
	idusuario INT,
	FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario)  
)

CREATE TABLE DietaAlimento ( 
    id_dieta INTEGER NOT NULL,
    id_alimento INTEGER NOT NULL,
    PRIMARY KEY (id_dieta, id_alimento),
    FOREIGN KEY (id_dieta) REFERENCES Dieta(iddieta),
    FOREIGN KEY (id_alimento) REFERENCES Alimento(idalimento)
)

CREATE TABLE DietaCondicion ( 
    id_dieta INTEGER NOT NULL,
    id_condicion INTEGER NOT NULL,
    PRIMARY KEY (id_dieta, id_condicion),
    FOREIGN KEY (id_dieta) REFERENCES Dieta(iddieta),
    FOREIGN KEY (id_condicion) REFERENCES Condicion(idcondicion)
)

CREATE TABLE InfoPaciente (
    idinfopaciente INTEGER IDENTITY (1, 1) PRIMARY KEY,
    idusuario INT,
    frecEjercicios VARCHAR(30),
    condicion VARCHAR(30),
    pesoCorporal DECIMAL(5, 2),
	estatura DECIMAL(5, 2),
    perimCintura DECIMAL(5, 2),
    perimCadera DECIMAL(5, 2),
    perimMuslo DECIMAL(5, 2),
    perimBrazo DECIMAL(5, 2),
    objetivo VARCHAR(20),
	estinfo VARCHAR(20),
	fechainfo DATETIME,
    FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario),
)

CREATE TABLE PacienteDieta ( 
	id_paciente INTEGER NOT NULL,
    id_dieta INTEGER NOT NULL,
    PRIMARY KEY (id_paciente, id_dieta),
	FOREIGN KEY (id_paciente) REFERENCES InfoPaciente(idinfopaciente),
    FOREIGN KEY (id_dieta) REFERENCES Dieta(iddieta)
)

CREATE TABLE TransaccionGeneral (
    idtrangeneral INTEGER IDENTITY (1, 1) PRIMARY KEY,
    fechatrans DATETIME, 
    desctrans VARCHAR(100),
	idusuario INT,
    idrutina INT,
    iddieta INT,
	idhorario INT,
	idinfopaciente INT,
	idreunion INT,
	idasistencia INT,
	FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario),
	FOREIGN KEY (idrutina) REFERENCES Rutina(idrutina),
    FOREIGN KEY (iddieta) REFERENCES Dieta(iddieta),
	FOREIGN KEY (idhorario) REFERENCES Horario(idhorario),
	FOREIGN KEY (idinfopaciente) REFERENCES InfoPaciente(idinfopaciente),
	FOREIGN KEY (idreunion) REFERENCES Reunion(idreunion),
	FOREIGN KEY (idasistencia) REFERENCES Asistencia(idasistencia)
)

CREATE TABLE TransaccionUsuario (
    idtransusu INTEGER IDENTITY (1, 1) PRIMARY KEY,
	idusuario INT,
	idtipousu INT,
	fecharegistro DATETIME,
    fechalogin DATETIME,
    fechalogout DATETIME,
    cambioPassword DATETIME,
	cambioCorreo DATETIME,
	fperfilactual DATETIME,
    FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario),
	FOREIGN KEY (idtipousu) REFERENCES TipoUsuario(idtipousu),
)

CREATE TABLE Notificacion (
	idnoti INTEGER IDENTITY (1, 1) PRIMARY KEY,
	idtrangeneral INT,
	rolnoti VARCHAR(20),
	mensaje VARCHAR(300),
	estnoti VARCHAR(20),
	diaSemana VARCHAR(20),
	timestamp DATETIME,
	FOREIGN KEY (idtrangeneral) REFERENCES TransaccionGeneral(idtrangeneral),
)


SELECT * FROM Notificacion

ALTER TABLE Notificacion
ADD diaSemana VARCHAR(10);

ALTER TABLE Notificacion
ADD FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario);

ALTER TABLE Notificacion
DROP CONSTRAINT [FK__Notificac__idusu__65370702]

ALTER TABLE Notificacion
DROP COLUMN idusuario;

SELECT * FROM TransaccionGeneral
ALTER TABLE TransaccionGeneral
ADD idasistencia INT;
ALTER TABLE TransaccionGeneral
ADD FOREIGN KEY (idasistencia) REFERENCES Asistencia(idasistencia);

SELECT * FROM TransaccionUsuario

INSERT INTO TipoUsuario VALUES('Paciente', 'Activo')
INSERT INTO TipoUsuario VALUES('Nutriologo', 'Activo')
INSERT INTO TipoUsuario VALUES('Administrador', 'Activo')
SELECT * FROM TipoUsuario

INSERT INTO Condicion VALUES('Ninguna', 'Activo')
INSERT INTO Condicion VALUES('Gluten', 'Activo')
INSERT INTO Condicion VALUES('Lacteos', 'Activo')
INSERT INTO Condicion VALUES('Carne', 'Activo')
SELECT * FROM Condicion

INSERT INTO Usuario
VALUES(1, 'Gonzalo', 'Tafur Bermudez', '2003-10-28', 'Peru', 'Masculino', 'Sin biografia', 'Activo', 'prueba@mail.com', 'prueba0123')
INSERT INTO Usuario
VALUES(2, 'Tester', 'Nutriologo', '1998-04-18', 'Peru', 'Masculino', 'Sin biografia', 'Activo', 'prueba2@mail.com', 'prueba1234')
/*INSERT INTO Usuario
VALUES(2, 'Usuario', 'Sistema', '2000-11-18', 'Peru', 'Masculino', 'Sin biografia', 'Activo', 'prueba3@mail.com', 'prueba12')*/
INSERT INTO Usuario
VALUES(3, 'Administrador', 'Tester', '1999-11-11', 'Peru', 'Masculino', NULL, 'Activo', 'admin@mail.com', 'admin123.')
SELECT * FROM Usuario

ALTER TABLE Usuario ALTER COLUMN password VARCHAR(255);

ALTER TABLE Usuario ADD usuario VARCHAR(30);


/*VALUES(1, NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)*/

ALTER TABLE InfoPaciente
DROP CONSTRAINT FK__PacienteD__id_pa__7A672E12
ALTER TABLE InfoPaciente
DROP COLUMN idusuario

SELECT 
    fk.name AS ForeignKey,
    tp.name AS ParentTable,
    cp.name AS ParentColumn,
    tr.name AS ReferencedTable,
    cr.name AS ReferencedColumn
FROM 
    sys.foreign_keys AS fk
INNER JOIN 
    sys.tables AS tp ON fk.parent_object_id = tp.object_id
INNER JOIN 
    sys.tables AS tr ON fk.referenced_object_id = tr.object_id
INNER JOIN 
    sys.foreign_key_columns AS fkc ON fk.object_id = fkc.constraint_object_id
INNER JOIN 
    sys.columns AS cp ON fkc.parent_object_id = cp.object_id AND fkc.parent_column_id = cp.column_id
INNER JOIN 
    sys.columns AS cr ON fkc.referenced_object_id = cr.object_id AND fkc.referenced_column_id = cr.column_id
WHERE tr.name = 'Notificacion';

ALTER TABLE TransaccionGeneral DROP CONSTRAINT FK__Transacci__idreu__51300E55;

DELETE FROM InfoPaciente WHERE idinfopaciente = 10;

UPDATE InfoPaciente
SET estinfo = 'Activo'
WHERE idinfopaciente = 25;

DELETE InfoPaciente
WHERE idinfopaciente = 44;

SELECT * FROM InfoPaciente

UPDATE Notificacion
SET estnoti = 'Inactivo'
WHERE idnoti = 10;

DELETE FROM Notificacion WHERE idtrangeneral = 2;
DELETE FROM TransaccionGeneral WHERE idtrangeneral = 2;


SELECT * FROM InfoPaciente

UPDATE InfoPaciente
SET estinfo = 'Inactivo'
WHERE idinfopaciente = 35;


SELECT * FROM Dieta

SELECT * FROM Reunion

UPDATE Asistencia
SET estasistencia = 'Inactivo'
WHERE idasistencia = 1;

INSERT INTO Asistencia VALUES(1, 1, SYSDATETIME(),'Activo')
SELECT * FROM Asistencia

SELECT * FROM Ejercicio


INSERT INTO Rutina VALUES('Rutina de Volumen', 'Intermedio', 'Rutina enfocada para ganar masa muscular', 'Activo', 2)
INSERT INTO Rutina VALUES('Fuerza Inferior 3', 'Deficit','Tren Inferior','Avanzado', 'Esta rutina solo es de prueba', 'Activo', 2)
SELECT * FROM Rutina

SELECT * FROM RutinaEjercicio

SELECT * FROM Alimento

INSERT INTO Dieta VALUES('Dieta #1', 'Deficit', 'Esta dieta solo es de prueba', 'Activo', 2)
INSERT INTO Dieta VALUES('Dieta #3', 'Volumen', 'Esta dieta solo es de prueba', 'Activo', 2)
SELECT * FROM Dieta

SELECT * FROM DietaAlimento
SELECT * FROM DietaCondicion

ALTER TABLE Horario
ADD descansoSerie VARCHAR(30);

ALTER TABLE Horario
ADD descansoEjer VARCHAR(30);

SELECT * FROM Horario

/*ALTER TABLE Horario
ADD CONSTRAINT [FK__Horario__idrutin__45F365D3]
ALTER TABLE Horario
ADD COLUMN idrutina;
ALTER TABLE Horario
DROP CONSTRAINT [FK__Rutina__idusuari__3E52440B]*/

ALTER TABLE Horario
DROP CONSTRAINT [FK__Horario__idusuar__44FF419A]
ALTER TABLE Horario
DROP COLUMN idusuario



SELECT * FROM PacienteDieta

SELECT * FROM Condicion