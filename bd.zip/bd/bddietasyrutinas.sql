USE master
GO

DROP DATABASE IF exists bddietasyrutinas

CREATE DATABASE bddietasyrutinas
GO

USE bddietasyrutinas
GO

CREATE TABLE TipoUsuario(
	idtipousu INTEGER IDENTITY (1, 1) PRIMARY KEY,
	nomtipousu VARCHAR(20),
	esttipousu VARCHAR(20),
)

CREATE TABLE Usuario(
	idusuario INTEGER IDENTITY (1, 1) PRIMARY KEY,
	idtipousu INT,
	nomusuario VARCHAR(20),
	apeusuario VARCHAR(50),
	fechanacimiento DATE,
	nacionalidad VARCHAR(20),
	sexo VARCHAR(10),
	biografia VARCHAR(200),
	estusuario VARCHAR(20),
	correo VARCHAR(50),
	password VARCHAR(50),
	FOREIGN KEY (idtipousu) REFERENCES TipoUsuario(idtipousu) 
)

/*CREATE TABLE Objetivo(
	idobjetivo INTEGER IDENTITY (1, 1) PRIMARY KEY,
	nomobjetivo VARCHAR(60),
	estobjetivo VARCHAR(20),
)*/

CREATE TABLE Ejercicio (
    idejercicio INTEGER IDENTITY (1, 1) PRIMARY KEY,
	nomejercicio VARCHAR(60),
	grupomuscular VARCHAR(30),
    tipoejercicio VARCHAR(30),
	series INT,
	repeticiones VARCHAR(10),
    descejercicio VARCHAR(300),
)

CREATE TABLE Rutina (
    idrutina INTEGER IDENTITY (1, 1) PRIMARY KEY,
	nomrutina VARCHAR(30),
    tiporutina VARCHAR(30),
	parteCuerpo VARCHAR(30),
    nivel VARCHAR(30),
    descrutina VARCHAR(700),
    estrutina VARCHAR(20),
    idusuario INTEGER,
    FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario)
)

CREATE TABLE RutinaEjercicio ( 
    id_rutina INTEGER NOT NULL,
    id_ejercicio INTEGER NOT NULL,
    PRIMARY KEY (id_rutina, id_ejercicio),
    FOREIGN KEY (id_rutina) REFERENCES Rutina(idrutina),
    FOREIGN KEY (id_ejercicio) REFERENCES Ejercicio(idejercicio)
)

DROP TABLE if exists Horario
CREATE TABLE Horario (
    idhorario INTEGER IDENTITY (1, 1) PRIMARY KEY,
    idusuario INT,
	idrutina INT,
    diaSemana VARCHAR(10),
    periodo VARCHAR(10),
	esthorario VARCHAR(20),
	/*tiempoDescanso INT,*/
	FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario),
	FOREIGN KEY (idrutina) REFERENCES Rutina(idrutina),
)

CREATE TABLE Alimento (
    idalimento INTEGER IDENTITY (1, 1) PRIMARY KEY,
    nomalimento VARCHAR(80),
    nutrientes VARCHAR(100),
    tipoalimento VARCHAR(30),
	descalimento VARCHAR(300)
)

CREATE TABLE Dieta (
    iddieta INTEGER IDENTITY (1, 1) PRIMARY KEY,
    nomdieta VARCHAR(60),
	objdieta VARCHAR(60),
    descdieta VARCHAR(900),
	estdieta VARCHAR(20),
	idusuario INT,
	FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario)  
)

CREATE TABLE DietaAlimento ( 
    id_dieta INTEGER NOT NULL,
    id_alimento INTEGER NOT NULL,
    PRIMARY KEY (id_dieta, id_alimento),
    FOREIGN KEY (id_dieta) REFERENCES Dieta(iddieta),
    FOREIGN KEY (id_alimento) REFERENCES Alimento(idalimento)
)

CREATE TABLE InfoPaciente (
    idinfopaciente INTEGER IDENTITY (1, 1) PRIMARY KEY,
    idusuario INT,
    frecEjercicios VARCHAR(30),
    condicion VARCHAR(30),
    pesoCorporal DECIMAL(5, 2),
	estatura DECIMAL(5, 2),
    perimCintura DECIMAL(5, 2),
    perimCadera DECIMAL(5, 2),
    perimMuslo DECIMAL(5, 2),
    perimBrazo DECIMAL(5, 2),
    objetivo VARCHAR(20),
    FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario),
)

DROP TABLE PacienteDieta
CREATE TABLE PacienteDieta ( 
	id_paciente INTEGER NOT NULL,
    id_dieta INTEGER NOT NULL,
	/*estpacdieta VARCHAR(10),*/
    PRIMARY KEY (id_paciente, id_dieta),
	FOREIGN KEY (id_paciente) REFERENCES InfoPaciente(idinfopaciente),
    FOREIGN KEY (id_dieta) REFERENCES Dieta(iddieta)
)

/*CREATE TABLE HorarioRutina ( 
    id_horario INTEGER NOT NULL,
    id_rutina INTEGER NOT NULL,
    PRIMARY KEY (id_horario, id_rutina),
    FOREIGN KEY (id_horario) REFERENCES Horario(idhorario),
    FOREIGN KEY (id_rutina) REFERENCES Rutina(idrutina)
)*/

DROP TABLE Transaccion
CREATE TABLE Transaccion (
    idtransaccion INTEGER IDENTITY (1, 1) PRIMARY KEY,
    fechatrans DATETIME, 
    tipotrans VARCHAR(50),
    idusuario INT,
    idrutina INT,
    iddieta INT,
	idhorario INT,
	idinfopaciente INT,
    FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario),
	FOREIGN KEY (idrutina) REFERENCES Rutina(idrutina),
    FOREIGN KEY (iddieta) REFERENCES Dieta(iddieta),
	FOREIGN KEY (idhorario) REFERENCES Horario(idhorario),
	FOREIGN KEY (idinfopaciente) REFERENCES InfoPaciente(idinfopaciente)
)

CREATE TABLE TransaccionUsuario (
    idtransusu INTEGER IDENTITY (1, 1) PRIMARY KEY,
	idusuario INT,
	idtipousu INT,
	fecharegistro DATETIME,
    fechalogin DATETIME,
    fechalogout DATETIME,
    cambioPassword DATETIME,
	cambioCorreo DATETIME,
	fperfilactual DATETIME,
    FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario),
	FOREIGN KEY (idtipousu) REFERENCES TipoUsuario(idtipousu),
)


/*CREATE TABLE TransaccionListas (
	idtranslistas INTEGER IDENTITY (1, 1) PRIMARY KEY,
	idejercicio INT,
	idalimento INT,
    FOREIGN KEY (idejercicio) REFERENCES Ejercicio(idejercicio),
	FOREIGN KEY (idalimento) REFERENCES Alimento(idalimento),
)

CREATE TABLE TransaccionGeneral (
    idtransgeneral INTEGER IDENTITY (1, 1) PRIMARY KEY,
	idtransaccion INT,
    idusuario INT,
	idejercicio INT,
    idrutina INT,
	idalimento INT,
    iddieta INT,
	idhorario INT,
	idinfopaciente INT,
    FOREIGN KEY (idusuario) REFERENCES Usuario(idusuario),
    FOREIGN KEY (idejercicio) REFERENCES Ejercicio(idejercicio),
	FOREIGN KEY (idrutina) REFERENCES Rutina(idrutina),
	FOREIGN KEY (idalimento) REFERENCES Alimento(idalimento),
    FOREIGN KEY (iddieta) REFERENCES Dieta(iddieta),
	FOREIGN KEY (idhorario) REFERENCES Horario(idhorario),
	FOREIGN KEY (idinfopaciente) REFERENCES InfoPaciente(idinfopaciente)
)*/

SELECT * FROM Transaccion
SELECT * FROM TransaccionUsuario

INSERT INTO TipoUsuario VALUES('Paciente', 'Activo')
INSERT INTO TipoUsuario VALUES('Nutriologo', 'Activo')
SELECT * FROM TipoUsuario

INSERT INTO Usuario
VALUES(1, 'Gonzalo', 'Tafur Bermudez', '2003-10-28', 'Peru', 'Masculino', 'Sin biografia', 'Activo', 'prueba@mail.com', 'prueba0123')
INSERT INTO Usuario
VALUES(2, 'Tester', 'Nutriologo', '1998-04-18', 'Peru', 'Masculino', 'Sin biografia', 'Activo', 'prueba2@mail.com', 'prueba1234')
/*INSERT INTO Usuario
VALUES(2, 'Usuario', 'Sistema', '2000-11-18', 'Peru', 'Masculino', 'Sin biografia', 'Activo', 'prueba3@mail.com', 'prueba12')*/
SELECT * FROM Usuario

/*VALUES(1, NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)*/
SELECT * FROM InfoPaciente


SELECT * FROM Dieta



SELECT * FROM Ejercicio


INSERT INTO Rutina VALUES('Rutina de Volumen', 'Intermedio', 'Rutina enfocada para ganar masa muscular', 'Activo', 2)
INSERT INTO Rutina VALUES('Fuerza Inferior 3', 'Deficit','Tren Inferior','Avanzado', 'Esta rutina solo es de prueba', 'Activo', 2)
SELECT * FROM Rutina

SELECT * FROM RutinaEjercicio

SELECT * FROM Alimento

INSERT INTO Dieta VALUES('Dieta #1', 'Deficit', 'Esta dieta solo es de prueba', 'Activo', 2)
INSERT INTO Dieta VALUES('Dieta #3', 'Volumen', 'Esta dieta solo es de prueba', 'Activo', 2)
SELECT * FROM Dieta

SELECT * FROM DietaAlimento


/*ALTER TABLE Horario
ADD COLUMN descansoSerie INT
ADD COLUMN descansoEjer INT*/
SELECT * FROM Horario

/*ALTER TABLE Horario
ADD CONSTRAINT [FK__Horario__idrutin__45F365D3]
ALTER TABLE Horario
ADD COLUMN idrutina;
ALTER TABLE Horario
DROP CONSTRAINT [FK__Rutina__idusuari__3E52440B]*/

ALTER TABLE Horario
DROP CONSTRAINT [FK__Horario__idusuar__44FF419A]
ALTER TABLE Horario
DROP COLUMN idusuario

SELECT * FROM PacienteDieta
